﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;
namespace Projekt_PAD_2
{
    public partial class search : UserControl
    {
        public Class1 c { get; set; }
        string str = "server=localhost;database=szkoly;userid=root;password=''";
        public search()
        {
            InitializeComponent();
            
        }
        
        
        private void label2_Click(object sender, EventArgs e)
        {

        }
        
        
        public void siticoneButton1_Click(object sender, EventArgs e)
        {

            Home h = new Home();
            string Komenda;

            //zależne sortowanie czy wpiszesz samo miasto/kierunek czy obydwa
            Class1.NP = szukaj_NP.Text;
            Class1.miasto = szukaj_M.Text;
            if (szukaj_NP.Text != "" && szukaj_M.Text == "")
            {
                Komenda = "Select Nazwa, Miasto, Kierunki, Ocena FROM szkola WHERE Kierunki LIKE '%" + Class1.NP + "%' ORDER BY Ocena Desc";

            }
            else if (szukaj_M.Text != "" && szukaj_NP.Text == "")
            {
                Komenda = "Select Nazwa, Miasto, Kierunki, Ocena FROM szkola WHERE Miasto LIKE '%" + Class1.miasto + "%' ORDER BY Ocena Desc";

            }
            else
            {
                Komenda = "Select Nazwa, Miasto, Kierunki, Ocena FROM szkola WHERE Kierunki LIKE '%" + Class1.NP + "%' AND Miasto LIKE '%" + Class1.miasto + "%' ORDER BY Ocena Desc";

            }
            h.BringToFront();
            XD(Komenda);




        }


        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void szukaj_NP_TextChanged(object sender, EventArgs e)
        {
           
            
        }

        public void XD(string komenda)
        {   //czyszczenie listy na początku
            
            MySqlConnection connection = null;
            MySqlDataReader reader = null;
            try
            {
                //łączenie z bazą danych
                connection = new MySqlConnection(str);
                connection.Open();
                MySqlCommand cmd = new MySqlCommand(komenda, connection);
                reader = cmd.ExecuteReader();
                //łączenie z bazą danych

                List<ListViewItem> item1 = new List<ListViewItem>();
                //polecenie któe się wykona po połączeniu z bazą i wykonaniu polecenia SQL
                while (reader.Read())
                {
                    
                    ListViewItem item = new ListViewItem();

                    item.Text = reader.GetString(0);
                    item.SubItems.Add(reader.GetString(1));
                    item.SubItems.Add(reader.GetString(2));
                    item.SubItems.Add(reader.GetFloat(3).ToString() + "/5");

                    item1.Add(item);

                }
                Class1.item = item1;





            }
            catch (MySqlException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }



    }
}
