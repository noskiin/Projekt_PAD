﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace Projekt_PAD_2
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            /*Home h = new Home();
            h.XD("Select Nazwa,Miasto,Kierunki,Ocena FROM szkola ORDER BY Ocena Desc");*/
        }

        private void siticonePanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void siticoneButton3_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Czy napewno chcesz wyłączyć program?", "SchoolX", MessageBoxButtons.YesNo,MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
            }
            else if(dialogResult == DialogResult.No)
            {

            }
        }

        private void siticoneButton2_Click(object sender, EventArgs e)
        {
            if (siticoneButton2.Checked) home1.BringToFront();
            
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            if (siticoneButton1.Checked)
            {
                search1.BringToFront();

            }
        }
        

        private void search1_Load(object sender, EventArgs e)
        {

        }

        private void siticoneButton4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("SchoolX - Czyli aplikacja pomagająca młodzieży i nie tylko w prosty sposób znaleźć najlepszą szkołę.");
        }
    }
}
