-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 31 Mar 2022, 22:02
-- Wersja serwera: 10.4.21-MariaDB
-- Wersja PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `szkoly`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `szkola`
--

CREATE TABLE `szkola` (
  `ID` int(11) NOT NULL,
  `Nazwa` varchar(255) COLLATE utf8mb4_polish_ci DEFAULT NULL,
  `Miasto` varchar(255) COLLATE utf8mb4_polish_ci DEFAULT NULL,
  `Kierunki` varchar(1000) COLLATE utf8mb4_polish_ci DEFAULT NULL,
  `Ocena` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Zrzut danych tabeli `szkola`
--

INSERT INTO `szkola` (`ID`, `Nazwa`, `Miasto`, `Kierunki`, `Ocena`) VALUES
(1, 'Powiatowy Zespół Szkół nr 2 im. Bohaterskiej Załogi ORP Orzeł', 'Wejherowo Strzelecka 9, 84-200 ', 'technik elektryk, technik elektronik, technik programista, technik informatyk, technik automatyk, technik teleinformatyk, elektryk', 3.1),
(2, '1 Liceum Ogólnokształcące im. Króla Jana III Sobieskiego', 'Wejherowo Bukowa 2C', 'klasa lingwistyczna - dwujęzyczna, klasa biologiczno-sportowa, klasa prawnicza, klasa zdrowia publicznego, klasa matematyczno-informatyczna, klasa matematyczno-geograficzna', 4.1),
(3, 'Powiatowy Zespół Szkół nr 4 im. Jakuba Wejhera w Wejherowa', 'Wejherowo Jana III Sobieskiego 344', 'klasa komunikacji międzynarodowej, klasa biologiczno-sportowa, klasa prawnicza, klasa zdrowia publicznego, klasa matematyczno-informatyczna, klasa matematyczno-geograficzna, technik spawalnictwa, technik pojazdów samochodowych, technik chłodnictwa i klimatyzacji, mechanik pojazdów samochodowych, elektromechanik pojazdów samochodowych, ślusarz, blacharz samochodowy, lakiernik samochodowy', 3.2),
(4, 'Powiatowy Zespół Szkół nr 3 ks. E. Roszczynialskiego', 'Wejherowo  Budowlanych 2', 'technik technologii żywności, technik spedytor, technik rachunkowości, technik logistyk, technik informatyk, technik programista, technik hotelarstwa, technik ekonomista, technik żywienia i usług gastronomicznych, technik organizacji turystyki, kucharz, sprzedawca, magazynier-logistyk', 3.6),
(5, '1 Liceum Ogólnokształcące im. Książąt Pomorskich', 'Rumia Starowiejska 4', 'klasa prawniczo-administracyjna, klasa dziennikarsko-medialna, klasa matematyczno-fizyczna, klasa matematyczno-informatyczna, klasa farmaceutyczno-medyczna, klasa dwujęzyczna, klasa ekonomiczna, klasa psychologiczno-społeczna', 3.7),
(6, 'Salezjańskie Liceum Ogólnokształcące im. św. J. Bosko', 'Rumia Świętojańska 1', 'klasa dwujęzyczna, klasa matematyczno-fizyczna, klasa prawnicza, klasa biologiczno-sportowa, klasa dziennikarska, klasa zdrowia publicznego', 3.8),
(7, 'Powiatowy Zespół Szkół nr 2 im. Hipolita Roszczynialskiego', 'Rumia Grunwaldzka 57', 'technik spedytor, technik logistyk, technik usług fryzjerskich, technik żywienia i usług gastronomicznych, technik obsługi turystycznej, technik hotelarstwa, technik przemysłu mody, fryzjer, kucharz, mechanik pojazdów samochodowych, sprzedawca, klasa wielozawodowa', 3.9),
(8, 'Powiatowy Zespół Szkół w Redzie', 'Reda Łąkowa 38', 'technik eksploatacji portów i terminali, technik geodeta, technik architektury krajobrazu, technik grafiki i poligrafii cyfrowej klasa E - Sportowa, technik organizacji reklamy, technik procesów drukowania, klasa mundurowa, klasa policyjna, klasa żeglarska', 2.6),
(9, 'Technium TEB Edukacja', 'Gdynia Śląska 37B, 81-310', 'technik programista, technik fotografii i multimediów, technik usług fryzjerskich, technik informatyk, technik reklamy, technik weterynarii, technik organizacji turystyki, technik rachunkowości', 2.9),
(10, 'Zespół Szkół Ekologiczno-Transportowych', 'Gdynia, Morska 186, 81-216', 'technik architektury krajobrazu, technik logistyk, technik spedytor, technik urządzeń i systemów energetyki odnawialnej, technik transportu kolejowego, technik automatyk sterowania ruchem kolejowym', 3.6),
(11, 'Centrum Kształcenia Zawodowego i Ustawicznego nr 1', 'Gdynia Morska 79, 81-222', 'technik pojazdów samochodowych, technik mechanik, technik mechanik lotniczy, technik budowy jednostek pływających, technik ekspoatacji portów i terminali', 2.8),
(12, 'Zespół Szkół Administracyjno - Ekonomicznych', 'Gdynia aleja Zwycięstwa 194, 81-540', 'technik ekonomista, technik rachunkowości, technik reklamy, technik grafiki i poligrafii cyfrowej', 2.6),
(13, 'Wojewódzki Zespół Szkół Policealnych w Gdyni', 'Gdynia Stefana Żeromskiego 31, 81-346', 'technik sterylizacji medycznej, technik usług kosmetycznych, technik masażysta', 4);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `szkola`
--
ALTER TABLE `szkola`
  ADD UNIQUE KEY `ID` (`ID`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `szkola`
--
ALTER TABLE `szkola`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
